<html>
<head>
<title>Test</title>
</head>
<body>
<?php
$host = "localhost";
$username = "root";
$password = "1234";
$objConnect = mysql_connect($host,$username,$password);

$objDB = mysql_select_db("training");

$strSQL = "SELECT * FROM users";
$objQuery = mysql_query($strSQL) or die (mysql_error());

?>
<table width="600" border="1">
  <tr>
    <th width="91"> <div align="center">ID </div></th>
    <th width="98"> <div align="center">Email </div></th>
    <th width="198"> <div align="center">Password </div></th>
    <th width="97"> <div align="center">Name </div></th>
  </tr>
<?php
while($objResult = mysql_fetch_array($objQuery))
{
?>
  <tr>
    <td><div align="center"><?php echo $objResult["id"];?></div></td>
    <td><div align="center"><?php echo $objResult["email"];?></div></td>
    <td><div align="center"><?php echo $objResult["password"];?></div></td>
    <td><div align="center"><?php echo $objResult["name"];?></div></td>
  </tr>
<?php
}
?>
</table>
<?php
mysql_close($objConnect);
?>
</body>
</html>
